package masterinslave

import "errors"

var (
	ErrNotImplemented = errors.New("this method of shadowed policy is not implemented")
)
